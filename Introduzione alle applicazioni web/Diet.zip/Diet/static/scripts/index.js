window.onload = function () {
    // window.onload è un evento che viene generato al caricamento della pagina. Qui noi facciamo un reinderizzamento da index.html a myProfile.html
    // evento associato a funzione. Generamente, la maggior parte degli eventi ha associata una funzione che non fa nulla
    window.location.href = "./static/html/company.html" // window.location.href specifica quale pagina html aprire
}
from flask import Flask, render_template, request, redirect, url_for, flash
from datetime import date, datetime, timedelta

from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from flask import send_from_directory
import os
import utenti_dao
import annunci_dao
import prenotazione_dao
from models import User
import utils as utils

app = Flask(__name__)
app.config['SECRET_KEY'] = 'chiave-segreta' 

from PIL import Image

import sqlite3


login_manager = LoginManager()
login_manager.init_app(app)

@app.errorhandler(404)
@app.errorhandler(500)
@app.errorhandler(Exception)  # Gestisce tutti gli altri errori
def gestisci_errori(error):
    app.logger.error(error)
    flash(utils.messaggio_di_errore_generico, "danger")
    return redirect(url_for("home"))

@app.route('/favicon.ico')
def favicon():
    return send_from_directory(os.path.join(app.root_path, 'static'),
                          'favicon.ico',mimetype='image/vnd.microsoft.icon')
    

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated == True:
        return redirect(url_for('home'))
    if request.method == 'POST':
        utente_form = request.form.to_dict()
        utente_db = utenti_dao.get_user_by_username(utente_form['username'])
        if utente_db["response"] == None or not check_password_hash(utente_db["response"]['password'], utente_form['password']): # DA FARE check_password_hash(utente_db['password'], utente_form['password']
            flash('Credenziali non valide, riprova', 'danger')
            return redirect(url_for('login'))
        else:
            new = User(id=utente_db["response"]['id'], email=utente_db["response"]["email"], username=utente_db["response"]['username'], password=utente_db["response"]['password'], tipo=utente_db["response"]['tipo'] )
            login_user(new, True)
            flash('Bentornato ' + utente_db["response"]['username'] + '!', 'success')

            return redirect(url_for('home'))

    return render_template('login.html')

@app.route('/registrazione', methods=['GET', 'POST'])
def registrazione():
    if current_user.is_authenticated == True:
        return redirect(url_for('home'))
    if request.method == 'POST':
        utente_form = request.form.to_dict()
        try:
            if utente_form["chkLocatore"] == "on":
                locatore = 0
            else:
                locatore = 1
        except Exception as e:
            locatore = 1
        response = utenti_dao.add_user(utente_form["email"], utente_form["username"], locatore, utente_form["password"])
        if(response["code"] == 0):
            flash("Utente creato.", "success")
            return redirect(url_for('login'))
        elif(response["code"] == -1):
            flash(response["response"], "danger")
            return redirect(url_for("registrazione"))
        else:
            flash(utils.messaggio_di_errore_generico, "danger")
            return redirect(url_for("registrazione"))
    else:
        return render_template('registrazione.html')

@login_manager.user_loader
def load_user(user_id):
    db_user = utenti_dao.get_user_by_id(user_id)["response"] # Accedo alla risposat, nel caso di eccezione response è None e non causa problemi
    if db_user is not None:
        user = User(id=db_user['id'], email=db_user['email'], username=db_user['username'], password=db_user['password'], tipo=db_user['tipo'])
    else:
        user = None

    return user

@app.route("/logout")
@login_required
def logout():
    logout_user()
    return redirect(url_for('home'))

@app.route('/home')
def home():
    filtro_annunci = request.args.get('filtro_annunci')
    if filtro_annunci == None:
        filtro_annunci = 0
    response = annunci_dao.get_annunci(int(filtro_annunci))
    if response["code"] == 0:
        return render_template('home.html', annunci = response["response"], filtro = str(filtro_annunci))
    elif(response["code"] == -1):
        flash(response["response"], "danger")
        return redirect(url_for("home"))
    else:
        flash(utils.messaggio_di_errore_generico, "danger")
        return redirect(url_for("home"))


@app.route('/dashboard', methods=['GET'])
@login_required
def dashboard():
    filtro = request.args.get('filtro')
    if filtro == None:
        filtro = 0
    if current_user.tipo == 1:
        filtro = 1
    response1 = prenotazione_dao.get_prenotazioni(int(filtro))
    if response1["code"] == 0:
        if current_user.tipo == 1:
            return render_template('dashboard.html', prenotazioni = response1["response"],  filtro = str(filtro))
        response2 = annunci_dao.get_annunci(4)
        if response2["code"] == 0:
            return render_template('dashboard.html', prenotazioni = response1["response"], annunci = response2["response"], filtro = str(filtro))
        elif(response1["code"] == -1):
            flash(response2["response"], "danger")
            return redirect(url_for("dashboard"))
        else:
            flash(utils.messaggio_di_errore_generico, "danger")
        return redirect(url_for("dashboard"))
    elif(response1["code"] == -1):
        flash(response1["response"], "danger")
        return redirect(url_for("dashboard"))
    else:
        flash(utils.messaggio_di_errore_generico, "danger")
        return redirect(url_for("dashboard"))

@app.route('/annuncio_dettaglio')
def annuncio_dettaglio():
    id_annuncio = int(request.args.get('id_annuncio'))
    response = annunci_dao.get_annuncio(id_annuncio)
    if response["code"] == 0:
        annuncio = response["response"]
        response = utenti_dao.get_user_by_id(response["response"]["id_locatore"])
        if response["code"] == 0:
            tmp = {"annuncio": annuncio, "locatore_username": response["response"]["username"]} # Passo anche lo username
            tmp["data_minima"] = (datetime.now() + timedelta(days=1)).strftime('%Y-%m-%d')
            tmp["data_massima"] = (datetime.now() + timedelta(days=7)).strftime('%Y-%m-%d')
            return render_template('annuncio_dettaglio.html', response = tmp )
    elif(response["code"] == -1):
        flash(response["response"], "danger")
        return redirect(url_for("dashboard"))
    else:
        flash(utils.messaggio_di_errore_generico, "danger")
        return redirect(url_for("dashboard"))

@app.route("/aggiorna_prenotazione", methods=['POST'])
@login_required
def aggiorna_prenotazione():
    prenotazione_form = request.form.to_dict()
    print(prenotazione_form)
    response = prenotazione_dao.aggiorna_prenotazione(id=int(prenotazione_form["id"]), stato=int(prenotazione_form["stato"]), motivazione=prenotazione_form["motivazione"])
    if(response["code"] == 0):
        flash("Aggiornamento prenotazione avvenuto con successo.", "success")
        return redirect(url_for("dashboard"))
    elif(response["code"] == -1):
        flash(response["response"], "danger")
        return redirect(url_for("dashboard"))
    else:
        flash(utils.messaggio_di_errore_generico, "danger")
        return redirect(url_for("dashboard"))

@app.route("/crea_prenotazione", methods=['POST'])
@login_required
def crea_prenotazione():
    prenotazione_form = request.form.to_dict()
    print(prenotazione_form)
    response = prenotazione_dao.add_prenotazione(int(prenotazione_form["id_annuncio"]), current_user.id, prenotazione_form["data"], int(prenotazione_form["fascia_oraria"]), int(prenotazione_form["presenza"]))
    if(response["code"] == 0):
        flash("Prenotazione effettuata con successo.", "success")
        return redirect(url_for("dashboard"))
    elif(response["code"] == -1):
        flash(response["response"], "danger")
        return redirect(url_for("dashboard"))
    else:
        flash(utils.messaggio_di_errore_generico, "danger")
        return redirect(url_for("dashboard"))

@app.route('/crea_annuncio', methods=['GET', 'POST'])
@login_required
def crea_annuncio():
    if request.method == 'POST':
        annuncio_form =  request.form.to_dict()
        print(annuncio_form)

        if 'files[]' not in request.files:
            return 'Errore: Nessun file selezionato', 400
        else:
            # Ottieni la lista di file dal campo 'files[]'
            files = request.files.getlist('files[]')

        response = annunci_dao.add_annuncio(files, titolo=annuncio_form["titolo"], indirizzo=annuncio_form["indirizzo"], tipo=int(annuncio_form["tipo"]), numero_locali=int(annuncio_form["numero_locali"]), descrizione=annuncio_form["descrizione"], prezzo_mensile=annuncio_form["prezzo_mensile"], arredata=annuncio_form["arredata"], id_locatore=current_user.id, disponibile=annuncio_form["disponibile"])

        if(response["code"] == 0):
            flash('Aggiornato', 'success')
            return redirect(url_for("home"))
        elif(response["code"] == -1):
            flash(response["response"], "danger")
            return redirect(url_for("crea_annuncio"))
        else:
            flash(utils.messaggio_di_errore_generico, "danger")
            return redirect(url_for("home"))
    else:
        tmp = {"id": -1}
        return render_template('gestione_annuncio.html', annuncio=tmp)

@app.route('/gestione_annuncio', methods=['GET', 'POST'])
@login_required
def gestione_annuncio():
    if request.method == 'POST':    
        annuncio_form =  request.form.to_dict()
        print(annuncio_form)

        if 'files[]' not in request.files:
            files = []
        else:
            # Ottieni la lista di file dal campo 'files[]'
            files = request.files.getlist('files[]')

        form_files = []
        for i in range(1, 6):
            try:
                form_files.append(int(annuncio_form["eliminaFile"+str(i)]))
            except Exception as e:
                pass

        response = annunci_dao.update_annuncio(annuncio_form["id"], current_user.id, files, form_files=form_files, titolo=annuncio_form["titolo"], tipo=int(annuncio_form["tipo"]), numero_locali=int(annuncio_form["numero_locali"]), descrizione=annuncio_form["descrizione"], prezzo_mensile=annuncio_form["prezzo_mensile"], arredata=annuncio_form["arredata"], disponibile=annuncio_form["disponibile"])
        
        if(response["code"] == 0):
            flash('Aggiornato', 'success')
            return redirect(url_for("home"))
        elif(response["code"] == -1):
            flash(response["response"], "danger")
            return redirect(url_for("home"))
        else:
            flash(utils.messaggio_di_errore_generico, "danger")
            return redirect(url_for("home"))
    else:
        id_annuncio = int(request.args.get('id_annuncio'))
        response = annunci_dao.get_annuncio(id_annuncio)
        if response["code"] == 0 and response["response"]["id_locatore"] == current_user.id:
            return render_template('gestione_annuncio.html', annuncio=response["response"])
        elif(response["code"] == -1):
            flash(response["response"], "danger")
            return redirect(url_for("dashboard"))
        else:
            flash(utils.messaggio_di_errore_generico, "danger")
            return redirect(url_for("dashboard"))

@app.route('/')
def index():
    return redirect(url_for("home"))


if __name__ == "__main__":
    app.run(host='127.0.0.1', port=3000)

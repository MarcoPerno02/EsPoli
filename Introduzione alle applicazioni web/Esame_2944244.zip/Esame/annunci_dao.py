import datetime
import os
import sqlite3
from time import sleep
from PIL import Image
import utenti_dao
import utils
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from app import app

PROFILE_IMG_HEIGHT = 500
POST_IMG_WIDTH = 1000

# Operazioni sugli Annunci
# Ogni funziona ritorna un dict con code che può essere -2 (Errore non gestito), -1 (Errore gestito) e 0 (default)
# e un campo response con un messaggio o i dati

# Traduzione del campo tipo nel db
tipi = [
    "Casa Indipendente",
    "Appartamento",
    "Loft",
    "Villa"
]

def get_annunci(modalita:int = 0):
    """Ritorna tutti gli annunci

    Args:
        modalita (int, optional): Filtro sulla restituzione degli annunci. 0 per la versione default, 1 per numero locali, 2 per annunci visibili del locatore, 3 per non annunci visibili del locatore, 4 per tutti gli annunci del locatore. Defaults to 1.

    Returns:
        annunci: Annunci da ritornare
    """
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        if modalita == 0:
            sql = 'SELECT * FROM annunci WHERE disponibile = 0 ORDER BY prezzo_mensile DESC'
            cursor.execute(sql)
        elif modalita == 1:
            sql = 'SELECT * FROM annunci  WHERE disponibile = 0 ORDER BY numero_locali ASC'
            cursor.execute(sql)
        elif modalita == 2:
            if current_user.tipo == 0:
                sql = 'SELECT * FROM annunci WHERE disponibile = 0 and id_locatore = ?'
                cursor.execute(sql, (current_user.id,))
            else:
                return {"code": -1, "response": "Non autorizzato"}
        elif modalita == 3:
            if current_user.tipo == 0:
                sql = 'SELECT * FROM annunci WHERE disponibile = 1 and id_locatore = ?'
                cursor.execute(sql, (current_user.id,))
            else:
                return {"code": -1, "response": "Non autorizzato"}
        else:
            if current_user.tipo == 0:
                sql = 'SELECT * FROM annunci WHERE id_locatore = ?'
                cursor.execute(sql, (current_user.id,))
            else:
                return {"code": -1, "response": "Non autorizzato"}
        annunci = cursor.fetchall() 
        cursor.close()
        conn.close()
        return {"code": 0, "response": annunci}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None} # Al client non ritorno nessuna informazione perchè è un comportamento anomalo il non funzionare di questa funzione

def get_annuncio(id):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM annunci where id=?'
        cursor.execute(sql, (id,))
        annuncio = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": annuncio}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None} # Al client non ritorno nessuna informazione perchè è un comportamento anomalo il non funzionare di questa funzione

def da_controllare(update, param):
    # Questa funzione specifica se controllare o no i parametri dell'annuncio in base se ho UPDATE o INSERT
    if (update == True and param != None) or update == False:
        return True
    return False

def valida_ritorna_query_annuncio(update, files, form_files = None, id = None, titolo = None, indirizzo = None, tipo = None, numero_locali = None, descrizione = None, prezzo_mensile = None, arredata = None, id_locatore = None, disponibile = None):
    """ La funzione serve per validare i dati dell'annuncio prima di inseriri nel db e ritona anche la query

    Args:
        update (bool): Se a True indica che si sta eseguendo un update, se a False indica che si sta inserendo un nuovo record
        files (list): files da salvare effettivamente
        form_files (list): form_files compilato dall'utente ceh specifica quali file nel db vuole ancora. Solo per UPDATE
        id (int, optional): id. Defaults to None. Solo per UPDATE
        titolo (str, optional): titolo. Defaults to None.
        indirizzo (str, optional): indirizzo. Defaults to None.
        tipo (str, optional): tipo. Defaults to None.
        numero_locali (int, optional): numero_locali. Defaults to None.
        descrizione (str, optional): descrizione. Defaults to None.
        prezzo_mensile (int, optional): prezzo_mensile. Defaults to None.
        arredata (int, optional): arredata. Defaults to None.
        id_locatore (int, optional): id_locatore. Defaults to None.
        disponibile (int, optional): disponibile. Defaults to None.
    """
    try:
        campi_str = ""
        values_str = ""
        values_list = []

        if(da_controllare(update, titolo)):
            if titolo == None or (len(titolo) <= 0 or len(titolo) > 50):
                return {"code": -1, "response": "Titolo non valido. Controlla la lunghezza tra 1 e 50."}
        if(update == False):
            values_str += "?, "
            campi_str += "titolo, "
            values_list.append(titolo)
        else:
            if(titolo != None):
                campi_str += "titolo = ?, "
                values_list.append(titolo)

        # Solo per INSERT
        if(update == False):
            if indirizzo == None or (len(indirizzo) <= 0 or len(indirizzo) > 50):
                return {"code": -1, "response": "Indirizzo non valido. Controlla la lunghezza tra 1 e 50."}
        if(update == False):
            values_str += "?, "
            campi_str += "indirizzo, "
            values_list.append(indirizzo)

        if(da_controllare(update, tipo)):
            if tipo == None or (tipo < 0 or tipo > 3):
                return {"code": -1, "response": "Tipo non valido"}
        if(update == False):
            values_str += "?, "
            campi_str += "tipo, "
            values_list.append(tipi[tipo])
        else:
            if(tipo != None):
                values_list.append(tipi[tipo])
                campi_str += "tipo = ?, "

        if(da_controllare(update, numero_locali)):
            if numero_locali == None or (int(numero_locali) <= 0 or int(numero_locali) > 6):
                return {"code": -1, "response": "numero_locali non valido"}
        if(update == False):
            values_str += "?, "
            campi_str += "numero_locali, "
            values_list.append(int(numero_locali))
        else:
            if(numero_locali != None):
                values_list.append(int(numero_locali))
                campi_str += "numero_locali = ?, "

        if(da_controllare(update, descrizione)):
            if descrizione == None or (len(descrizione) <= 0 or len(descrizione) > 300):
                return {"code": -1, "response": "descrizione non valido"}
        if(update == False):
            values_str += "?, "
            campi_str += "descrizione, "
            values_list.append(descrizione)
        else:
            if(descrizione != None):
                values_list.append(descrizione)
                campi_str += "descrizione = ?, "

        if(da_controllare(update, prezzo_mensile)):
            if prezzo_mensile == None or (int(prezzo_mensile) <= 0):
                return {"code": -1, "response": "prezzo_mensile non valido"}
        if(update == False):
            values_str += "?, "
            campi_str += "prezzo_mensile, "
            values_list.append(int(prezzo_mensile))
        else:
            if(prezzo_mensile != None):
                values_list.append(int(prezzo_mensile))
                campi_str += "prezzo_mensile = ?, "

        if(da_controllare(update, arredata)):
            if arredata == None or (int(arredata) != 0 and int(arredata) != 1):
                return {"code": -1, "response": "arredata non valido"}
        if(update == False):
            values_str += "?, "
            campi_str += "arredata, "
            values_list.append(int(arredata))
        else:
            if(arredata != None):
                values_list.append(int(arredata))
                campi_str += "arredata = ?, "

        # Solo per inserimento prima volta
        if id_locatore == None:
            return {"code": -1, "response": "id_locatore non valido"}
        if(update == False):
            values_str += "?, "
            values_list.append(int(id_locatore))
            campi_str += "id_locatore, "

        if(da_controllare(update, disponibile)):
            if disponibile == None or (int(disponibile) != 0 and int(disponibile) != 1):
                return {"code": -1, "response": "disponibile non valido"}
        if(update == False):
            values_str += "?, "
            campi_str += "disponibile, "
            values_list.append(int(disponibile))
        else:
            if(disponibile != None):
                values_list.append(int(disponibile))
                campi_str += "disponibile = ?, "

        # Gestione files
        if da_controllare(update, files):
            if update == True:
                if form_files == None:
                    return {"code": -1, "response": "form_files non valido"}

                # Guardo quali file sono salvati nel db
                files_in_static = getListFileForAnnuncio(id)

                # Costruisco la nuova stringa di files in base a quali files tenere
                new_files_str = ""
                tmp_to_delete = []
                count = 0
                for i in range(len(files_in_static)):
                    try:
                        if form_files[i] == 1:
                            new_files_str += files_in_static[i] +";"
                            count+=1
                        else:
                            tmp_to_delete.append(files_in_static[i])
                    except:
                        pass
                
                # Lista dei file da aggiungere
                if files[0].filename == "": # Elimino il primo file se è vuoto perchè se non carico foto di defualt c'è questo
                    del files[0]
                if count + len(files) > 5:
                    return {"code": -1, "response": "Troppi files passati"}
                if count + len(files) == 0:
                    return {"code": -1, "response": "Impossibile non caricare foto"}
                for file in files:
                    try:
                        tmp = salvaFile(str(id_locatore), file)
                        new_files_str += tmp +";"
                    except Exception as e:
                        return {"code": -1, "response": "File corrotto"}

                for file in tmp_to_delete:
                    percorso_file = os.path.join(app.root_path, 'static', file)
                    try:
                        # Elimina il file
                        os.remove(percorso_file)
                        print("File eliminato con successo.")
                    except OSError as e:
                        err = f"Errore durante l'eliminazione del file: {e.strerror}"
                        print(err)
                    
                campi_str += "files = ?"
                new_files_str = new_files_str[:-1]
                values_list.append(new_files_str)
            else:
                new_files_str = ""
                if files[0].filename == "":
                    del files[0]
                if (len(files) > 5 or len(files) <= 0):
                    return {"code": -1, "response": "Numero Files passati non valido. Deve essere da 1 a 5"}
                for file in files:
                    try:
                        tmp = salvaFile(str(id_locatore), file)
                        new_files_str += tmp +";"
                    except Exception as e:
                        return {"code": -1, "response": "File corrotto"}
                values_str += "?"
                new_files_str = new_files_str[:-1]
                values_list.append(new_files_str)
                campi_str += "files"
        
        # Ritorno la query da eseguire
        if(update == True):
            if(id == None or get_annuncio(id)["response"] == None):
                return {"code": -1, "response": "id_annuncio non valido"}
            query = "UPDATE annunci SET " + campi_str + " WHERE id = ?"
            values_list.append(int(id))
        else:
            query = "INSERT INTO annunci (" + campi_str + ") VALUES(" + values_str + ")"
        return {"code": 0, "query": query, "values_list": values_list}
    except Exception as e:
        print(str(e))
        return {"code": -1, "response": "Errore nell'update. Riprovare pìù tardi"}
    

def add_annuncio(files, titolo, indirizzo, tipo, numero_locali, descrizione, prezzo_mensile, arredata, id_locatore, disponibile):
    try:
        response = valida_ritorna_query_annuncio(update=False, files=files, titolo=titolo, indirizzo=indirizzo, tipo=tipo, numero_locali=numero_locali, descrizione=descrizione, prezzo_mensile=prezzo_mensile, arredata=arredata, id_locatore=id_locatore, disponibile=disponibile)
        if(response["code"] == 0):
            conn = sqlite3.connect('db/esame.db')
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            try:
                cursor.execute(response["query"], response["values_list"])
                conn.commit()
                cursor.close()
                conn.close()
            except Exception as e:
                print('ERROR', str(e))
                # if something goes wrong: rollback
                conn.rollback()
                cursor.close()
                conn.close()
                raise Exception(utils.messaggio_di_errore_generico)
            return {"code": 0}
        return response
    except Exception as e:
        print(e)
        return {"code": -2, "response": utils.messaggio_di_errore_generico}

def update_annuncio(id, id_locatore, files, form_files, titolo = None, tipo = None, numero_locali = None, descrizione = None, prezzo_mensile = None, arredata = None, disponibile = None):
    try:
        response = valida_ritorna_query_annuncio(update=True, files=files, form_files=form_files, id=id, titolo=titolo, tipo=tipo, numero_locali=numero_locali, descrizione=descrizione, prezzo_mensile=prezzo_mensile, arredata=arredata, id_locatore=id_locatore, disponibile=disponibile)
        if(response["code"] == 0):
            conn = sqlite3.connect('db/esame.db')
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            try:
                cursor.execute(response["query"], response["values_list"])
                conn.commit()
                cursor.close()
                conn.close()
            except Exception as e:
                print('ERROR', str(e))
                # if something goes wrong: rollback
                conn.rollback()
                cursor.close()
                conn.close()
                raise Exception(utils.messaggio_di_errore_generico)
            return {"code": 0}
        return response
    except Exception as e:
        print(e)
        return {"code": -2, "response": utils.messaggio_di_errore_generico}

    return annuncio
def getListFileForAnnuncio(id):
    conn = sqlite3.connect('db/esame.db')
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()

    sql = 'SELECT files FROM annunci where id=?'
    cursor.execute(sql, (id,))
    annuncio = cursor.fetchone()

    cursor.close()
    conn.close()

    return annuncio["files"].split(";")

def ottieni_timestamp_attuale():
    return int(datetime.datetime.now().timestamp())

def salvaFile(id, file):
    sleep(1) # Rallento altrimenti c'è il rischio che una foto venga sovrascritta dall'altra perchè la funzione genera stesso timestamp
    img = Image.open(file)

    # Get the width and height of the image
    width, height = img.size

    # Calculate the new height while maintaining the aspect ratio based on the desired width
    new_height = height/width * POST_IMG_WIDTH

    # Define the size for thumbnail creation with the desired width and calculated height
    size = POST_IMG_WIDTH, new_height
    img.thumbnail(size, Image.Resampling.LANCZOS)

    # Extracting file extension from the image filename
    ext = file.filename.split('.')[-1]
    # Getting the current timestamp in seconds
    secondi = ottieni_timestamp_attuale()
    print(secondi)

    # Saving the image with a unique filename in the 'static' directory
    img.save('static/' + "id" + id + '-' + str(secondi) + '.' + ext)
    return "id" + id + '-' + str(secondi) + '.' + ext
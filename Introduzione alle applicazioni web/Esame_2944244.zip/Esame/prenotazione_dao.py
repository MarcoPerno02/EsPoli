import datetime
import sqlite3
from utils import controlla_formato_data
import annunci_dao
import utenti_dao
# Operazioni sulle Prenotazioni
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
import utils as utils

def get_prenotazioni(filtro:int = 1):
    """Restituisci prenotazioni

    Args:
        filtro (int): 0 per modalità locatore, 1 per modalità cliente. Defaults to 1.

    Returns:
        _type_: _description_
    """
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        if(current_user.tipo == 0 and filtro == 0):
            # Locatore
            sql = 'SELECT p.*, a.titolo, u.username FROM prenotazioni p, annunci a, utenti u WHERE p.id_annuncio = a.id and p.id_visitatore = u.id and a.id_locatore = ?'
            id = current_user.id
            cursor.execute(sql, (id,))
            prenotazioni = cursor.fetchall() 
            cursor.close()
            conn.close()
            return {"code": 0, "response": prenotazioni}
        else:
            # Cliente
            sql = 'SELECT p.*, a.titolo, u.username FROM prenotazioni p, annunci a, utenti u WHERE  p.id_annuncio = a.id and  p.id_visitatore = ? and p.id_visitatore = u.id'
            id = current_user.id
            cursor.execute(sql, (id,))
            prenotazioni = cursor.fetchall() 
            cursor.close()
            conn.close()
            return {"code": 0, "response": prenotazioni}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None} # Al client non ritorno nessuna informazione perchè è un comportamento anomalo il non funzionare di questa funzione

def get_prenotazione(id):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM prenotazioni where id=?'
        cursor.execute(sql, (id,))
        prenotazione = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": prenotazione}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None} # Al client non ritorno nessuna informazione perchè è un comportamento anomalo il non funzionare di questa funzione

def get_prenotazione_id_annuncio_data_e_fascia_oraria_stato(id_annuncio, data, fascia_oraria, stato):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM prenotazioni where id_annuncio=? and data=? and fascia_oraria=? and stato=?'
        cursor.execute(sql, (id_annuncio, data, fascia_oraria, stato))
        prenotazione = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": prenotazione}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None} # Al client non ritorno nessuna informazione perchè è un comportamento anomalo il non funzionare di questa funzione

def get_prenotazione_id_annuncio_id_visitatore_stato(id_annuncio, id_visitatore, stato):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM prenotazioni where id_annuncio=? and id_visitatore=? and stato=?'
        cursor.execute(sql, (id_annuncio, id_visitatore, stato))
        prenotazione = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": prenotazione}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None} # Al client non ritorno nessuna informazione perchè è un comportamento anomalo il non funzionare di questa funzione


def valida_ritorna_query_prenotazione(update, id=None, id_annuncio=None, id_visitatore=None, data=None, fascia_oraria=None, presenza=None, stato=None, motivazione=None): 
    """ La funzione serve per validare i dati dell'annuncio prima di inseriri nel db e ritona anche la query

    Args:
        update (bool): Se a True indica che si sta eseguendo un update, se a False indica che si sta inserendo un nuovo record
        id (int, optional): id prenotazione. Defaults to None. Solo per UPDATE
        id_annuncio (int, optional): id annuncio associato. Defaults to None. Solo per INSERT
        id_visitatore (int, optional): id visitatore associato. Defaults to None. Solo per INSERT
        data (str, optional): data visita. Defaults to None. Solo per INSERT
        fascia_oraria (int, optional): fascia oraria della visita. Defaults to None. Solo per INSERT
        presenza (int, optional): Presenza 0, a distanza 1. Defaults to None. Solo per INSERT
        stato (int, optional): 0 (in attesa) o 1 (accettato) o 2 (rifiutato). Defaults to None. Solo per UPDATE
        motivazione (str, optional): stringa per motivare il rifiuto. Defaults to None. Solo per UPDATE
    """
    campi_str = ""
    values_str = ""
    values_list = []

    # Solo per UPDATE
    if(update == True):
        prentazione_db = get_prenotazione(id)
        if id == None or current_user.tipo != 0 or prentazione_db["response"] == None or prentazione_db["response"]["stato"] != 0:
            return {"code": -1, "response": "Id non valido"}
        annuncio_db = annunci_dao.get_annuncio(prentazione_db["response"]["id_annuncio"])
        if(annuncio_db["response"]["id_locatore"] != current_user.id): # Controllo anche che la prenotazione sia riferita effettivamnete a quel locatore
            return {"code": -1, "response": "Id non valido"}
    
    # Solo per INSERT
    if(update == False):
        if id_annuncio == None or (annunci_dao.get_annuncio(id_annuncio)["response"] == None):
            return {"code": -1, "response": "Id_annuncio non valido"}
    if(update == False):
        values_str += "?, "
        campi_str += "id_annuncio, "
        values_list.append(id_annuncio)

    # Solo per INSERT
    if(update == False):
        if id_visitatore == None or (utenti_dao.get_user_by_id(id_visitatore)["response"] == None) or (annunci_dao.get_annuncio(id_annuncio)["response"]["id_locatore"] == id_visitatore): # Controllo che locatore non prenoti una visista per la sua casa
            return {"code": -1, "response": "Impossibile prenotare visita per il proprio annuncio"}
    if(update == False):
        values_str += "?, "
        campi_str += "id_visitatore, "
        values_list.append(id_visitatore)

    # Solo per INSERT
    if(update == False):
        if fascia_oraria == None or (fascia_oraria < 1 or fascia_oraria > 4):
            return {"code": -1, "response": "Fascia oraria non valida"}
    if(update == False):
        values_str += "?, "
        campi_str += "fascia_oraria, "
        values_list.append(fascia_oraria)
    
    # Solo per INSERT
    if(update == False):
        if presenza == None or (presenza < 0 or presenza > 1):
            return {"code": -1, "response": "Presenza non valida"}
    if(update == False):
        values_str += "?, "
        campi_str += "presenza, "
        values_list.append(presenza)
    
    # Solo per UPDATE
    if(update == True):
        if stato == None or (stato != 1 and stato != 2):
            return {"code": -1, "response": "Stato non valido"}
    if(update == True):
        values_list.append(stato)
        campi_str += "stato = ?, "
    
    # Solo per UPDATE
    if(update == True):
        if stato == 2 and (motivazione == None or motivazione == ""):
            return {"code": -1, "response": "Motivazione non valida"}
        if stato == 1:
            motivazione = ""
    if(update == True):
        values_list.append(motivazione)
        campi_str += "motivazione = ? "

    #TODO Controllo chiavi univoche
    # Solo per INSERT
    if(update == False):
        if data == None or (controlla_formato_data(data) == False):
            return {"code": -1, "response": "Data non valida"}
        tmp = datetime.datetime.strptime(data, '%Y-%m-%d')
        oggi = datetime.datetime.now()
        sette_giorni_dopo = oggi + datetime.timedelta(days=7)
        if (oggi <= tmp <= sette_giorni_dopo) == False:
            return {"code": -1, "response": "La data non è tra 1 e 7 giorni dopo oggi."}
        if get_prenotazione_id_annuncio_data_e_fascia_oraria_stato(id_annuncio, data, fascia_oraria, 1)["response"] != None:
            return {"code": -1, "response": "Gìa presenta una prenotazione per quella fascia oraria"}
        if get_prenotazione_id_annuncio_id_visitatore_stato(id_annuncio, id_visitatore, 0)["response"] != None or get_prenotazione_id_annuncio_id_visitatore_stato(id_annuncio, id_visitatore, 1)["response"] != None:
            return {"code": -1, "response": "Hai già una visita in programma o è gia stata fatta."}
    if(update == False):
        values_str += "?, "
        campi_str += "data, "
        values_list.append(data)
    
    # Ritorno la query da eseguire
    if(update == True):
        query = "UPDATE prenotazioni SET " + campi_str + " WHERE id = ?"
        values_list.append(int(id))
    else:
        query = "INSERT INTO prenotazioni (" + campi_str + " stato) VALUES(" + values_str + " 0)"
    return {"code": 0, "query": query, "values_list": values_list}

def add_prenotazione(id_annuncio, id_visitatore, data, fascia_oraria, presenza):
    try:
        response = valida_ritorna_query_prenotazione(update=False, id_annuncio=id_annuncio, id_visitatore=id_visitatore, data=data, fascia_oraria=fascia_oraria, presenza=presenza)
        if(response["code"] == 0):
            conn = sqlite3.connect('db/esame.db')
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            try:
                cursor.execute(response["query"], response["values_list"])
                conn.commit()
                cursor.close()
                conn.close()
            except Exception as e:
                print('ERROR', str(e))
                # if something goes wrong: rollback
                conn.rollback()
                cursor.close()
                conn.close()
                raise Exception(utils.messaggio_di_errore_generico)
            return {"code": 0}
        return response
    except Exception as e:
        print(e)
        return {"code": -2, "response": utils.messaggio_di_errore_generico}

def aggiorna_prenotazione(id:int, stato:int, motivazione:str = None):
    """Aggiorna lo stato della prenotazione

    Args:
        id (int): id prenotazione
        stato (int): Nuovo stato prenotazione
        motivazione (str): Motivazione da passare SOLO in caso di rifiuto
    """
    try:
        response = valida_ritorna_query_prenotazione(update=True, id=id, stato=stato, motivazione=motivazione)
        if(response["code"] == 0):
            conn = sqlite3.connect('db/esame.db')
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            try:
                cursor.execute(response["query"], response["values_list"])
                conn.commit()
                success = True
            except Exception as e:
                print('ERROR', str(e))
                # if something goes wrong: rollback
                conn.rollback()
                cursor.close()
                conn.close()
                raise Exception(utils.messaggio_di_errore_generico)
            return {"code": 0}
        return response
    except Exception as e:
        print(e)
        return {"code": -2, "response": utils.messaggio_di_errore_generico}
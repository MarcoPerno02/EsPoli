import datetime

messaggio_di_errore_generico = "Qualocosa è andato storto. Riprovare più tardi."


def controlla_formato_data(data_stringa):
    formato_corretto = "%Y-%m-%d"
    
    try:
        # Provo a parsare la stringa con il formato specificato
        datetime.datetime.strptime(data_stringa, formato_corretto)
        return True  # Se la stringa è stata parsata correttamente, restituisco True
    except ValueError:
        return False  # Se si verifica un errore, restituisco False
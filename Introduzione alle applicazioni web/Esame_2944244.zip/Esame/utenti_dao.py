import sqlite3
import utils
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash

def valida_ritorna_query_utenti(update, email=None, username=None, tipo=None, password=None):
    campi_str = ""
    values_str = ""
    values_list = []

    if(update == False):
        if email == None or (email == "") or (get_user_by_email(email)["response"] != None):
            return {"code": -1, "response": "Email non valida"}
    if(update == False):
        values_str += "?, "
        campi_str += "email, "
        values_list.append(email)
    
    if(update == False):
        if username == None or (username == "") or (get_user_by_username(username)["response"] != None):
            return {"code": -1, "response": "Username non valido oppure già esistente"}
    if(update == False):
        values_str += "?, "
        campi_str += "username, "
        values_list.append(username)
    
    if(update == False):
        if tipo == None or (tipo != 0 and tipo != 1):
            return {"code": -1, "response": "Tipo non valido"}
    if(update == False):
        values_str += "?, "
        campi_str += "tipo, "
        values_list.append(tipo)
    
    if(update == False):
        if password == None or (password == ""):
            return {"code": -1, "response": "Password non valida"}
    if(update == False):
        values_str += "? "
        campi_str += "password "
        values_list.append(generate_password_hash(password))

    if(update == False):
        query = "INSERT INTO utenti (" + campi_str + ") VALUES(" + values_str + ")"
    return {"code": 0, "query": query, "values_list": values_list}
    


def add_user(email, username, tipo, password):
    try:
        response = valida_ritorna_query_utenti(update=False, email=email, username=username, tipo=tipo, password=password)
        if(response["code"] == 0):
            conn = sqlite3.connect('db/esame.db')
            conn.row_factory = sqlite3.Row
            cursor = conn.cursor()
            try:
                cursor.execute(response["query"], response["values_list"])
                conn.commit()
                cursor.close()
                conn.close()
            except Exception as e:
                print('ERROR', str(e))
                # if something goes wrong: rollback
                conn.rollback()
                cursor.close()
                conn.close()
                raise Exception(utils.messaggio_di_errore_generico)
            return {"code": 0}
        return response
    except Exception as e:
        print(e)
        return {"code": -2, "response": utils.messaggio_di_errore_generico}

def get_user_by_id(id):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM utenti WHERE id = ?'
        cursor.execute(sql, (id,))
        user = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": user}
    except Exception as e:
        return {"code": -2, "response": None}

# Funzione ausiliare per cercare l'id di un utente dato il suo nickname

def get_user_by_username(username):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM utenti WHERE username = ?'
        cursor.execute(sql, (username,))
        user = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": user}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None}

def get_user_by_email(email):
    try:
        conn = sqlite3.connect('db/esame.db')
        conn.row_factory = sqlite3.Row
        cursor = conn.cursor()

        sql = 'SELECT * FROM utenti WHERE email = ?'
        cursor.execute(sql, (email,))
        user = cursor.fetchone()

        cursor.close()
        conn.close()

        return {"code": 0, "response": user}
    except Exception as e:
        print(str(e))
        return {"code": -2, "response": None}
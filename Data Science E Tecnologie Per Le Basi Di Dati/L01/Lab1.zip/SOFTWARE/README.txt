For the execution of the lab, we suggest to use Oracle Live or Oracle DB, if installed on the pcs inside the lab. 
You can find the instructions for both softwares inside the files "0 - SoftwareInstruction_OracleLive.pdf" and "0 - SoftwareInstruction_OracleDB.pdf" (in Addidional files - OracleDB)

If you want to install Oracle DB on your own pc, we provide the guides for Windows, Ubuntu and MacOS in the "Addidional files - OracleDB" folder. 
The installation process is up to you.